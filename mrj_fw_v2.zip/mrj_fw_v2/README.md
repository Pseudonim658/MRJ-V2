<div align="center">

<img src="https://img.shields.io/badge/ESP32-DevKit_V1-ff6b6b?style=for-the-badge&logo=espressif&logoColor=white" />
<img src="https://img.shields.io/badge/Firmware-V2.1.0-4ecdc4?style=for-the-badge&logo=arduino&logoColor=white" />
<img src="https://img.shields.io/badge/PlatformIO-Build-green?style=for-the-badge&logo=platformio&logoColor=white" />
<img src="https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge" />

# 🔥 MRJ FIRMWARE V2

**All-in-One ESP32 Wireless Security Testing & IoT Hardware Control**

*Firmware ESP32 serba-guna untuk pengujian keamanan nirkabel, IoT, dan kontrol hardware*

</div>

---

## 🌐 Languages / Bahasa

- 🇬🇧 [English](#english-section)
- 🇮🇩 [Indonesia](#indonesia-section)

---

<a name="english-section"></a>
# 🇬🇧 English

## 📋 Overview

MRJ Firmware V2 is a powerful, all-in-one firmware for ESP32 DevKit V1 designed for wireless security testing, IoT device analysis, and hardware control. Built with modular architecture and team-based pin sharing system to maximize GPIO efficiency.

## ✨ Features

| Category | Features |
|----------|----------|
| **🖥️ Display** | ST7735 TFT 1.77" 128x160 with splash screen, boot progress, menu system |
| **📡 WiFi** | Deauth attack, Evil Twin, Captive Portal, Beacon Spam, Network Scanner |
| **📶 BLE** | Device Scanner, BLE Spam, Advertisement Analyzer |
| **📻 Sub-GHz** | CC1101 support (300-928 MHz), frequency scan, RX/TX |
| **🆔 RFID/NFC** | MFRC522 (13.56 MHz), PN532 NFC, EM4100 (125 kHz) read/clone/emulate |
| **🔑 iButton** | Dallas/Maxim 1-Wire key read & emulate |
| **🔴 IR Remote** | Record, Play, Decode (NEC/Sony/RC5 protocols) |
| **⌨️ BadUSB** | CH9326 HID Keyboard automation (Ducky Script style) |
| **🔧 GPIO Control** | Web-based pin control with reserved pin protection |
| **💾 SD Card** | File manager, logging, capture storage, script execution |
| **🌐 Web Dashboard** | Full control via browser with JSON API |
| **📦 OTA Update** | Firmware update over WiFi |
| **⚙️ Module Control** | Enable/disable modules without restart (EEPROM) |

## 🏗️ Architecture / Team System

```
┌─────────────────────────────────────────────────────────────┐
│                    MRJ V2 TEAM SYSTEM                      │
├──────────────────────────────┬──────────────────────────────┤
│        🔴 TEAM A             │        🔵 TEAM B           │
│     (Attack/Transmit)        │      (Read/Clone)          │
├──────────────────────────────┼──────────────────────────────┤
│  📻 CC1101 (Sub-GHz)        │  📡 NFC PN532 (I2C)        │
│  ⌨️ CH9326 (BadUSB)         │  🆔 RFID MFRC522 (SPI)     │
│                              │  🆔 RFID 125kHz (UART)     │
├──────────────────────────────┴──────────────────────────────┤
│  ⚔️ Mutual Exclusion: Team A active → Team B auto-disabled │
│  ⚔️ Shared Pins: GPIO 0, 3, 15, 39 (time-sharing)        │
└─────────────────────────────────────────────────────────────┘
```

> **Why Teams?** Team A and Team B use the same pins but never run simultaneously. This pin-sharing design allows 4 optional modules to run using only 4 extra GPIO pins!

## 📌 Pinout Diagram

![MRJ V2 Pinout](mrj%20v2.png)

<details>
<summary>📎 Click to view detailed pin table</summary>

### Core Modules (Always Active)

| Module | ESP32 Pin | Type |
|--------|-----------|------|
| TFT ST7735 SCK | GPIO 18 | VSPI |
| TFT ST7735 MISO | GPIO 19 | VSPI |
| TFT ST7735 MOSI | GPIO 23 | VSPI |
| TFT ST7735 CS | GPIO 5 | VSPI |
| TFT ST7735 DC | GPIO 21 | VSPI |
| TFT ST7735 RST | GPIO 22 | VSPI |
| SD Card SCK | GPIO 14 | HSPI |
| SD Card MISO | GPIO 26 | HSPI |
| SD Card MOSI | GPIO 27 | HSPI |
| SD Card CS | GPIO 4 | HSPI |
| NFC SDA | GPIO 16 | I2C |
| NFC SCL | GPIO 17 | I2C |
| NFC IRQ | GPIO 35 | Input |
| IR Receiver | GPIO 36 | Input-Only |
| IR Transmitter | GPIO 12 | Output |
| iButton Data | GPIO 2 | 1-Wire |
| Buzzer PWM | GPIO 13 | PWM |
| Button UP | GPIO 32 | Input |
| Button DOWN | GPIO 33 | Input |
| Button SELECT | GPIO 25 | Input |
| Button BACK | GPIO 34 | Input-Only |
| Battery ADC | GPIO 37 | ADC |

### Shared Pins (Team A ↔ Team B)

| Pin | Team A (Active) | Team B (Active) |
|-----|-----------------|-------------------|
| GPIO 0 | CC1101 CS | RFID CS |
| GPIO 3 | CC1101 GDO0 | RFID RST |
| GPIO 15 | CH9326 TX | RFID125 TX |
| GPIO 39 | CH9326 RX | RFID125 RX |

</details>

## 📁 Project Structure

```
mrj_fw_v2/
├── 📄 platformio.ini          # Build configuration
├── 📁 src/                    # Source code
│   ├── 📄 MRJ_FW_V2.ino      # Main entry point
│   ├── 📄 config.h           # Firmware constants & EEPROM layout
│   ├── 📄 hardware_pinout.h  # GPIO pin definitions
│   │
│   ├── 🖥️ Display System
│   │   ├── display.h / display.cpp
│   │
│   ├── 🧠 Core Managers
│   │   ├── eeprom_manager.h / eeprom_manager.cpp
│   │   ├── reserved_pins.h / reserved_pins.cpp
│   │   ├── logger.h / logger.cpp
│   │   ├── sd_card.h / sd_card.cpp
│   │   ├── menu.h / menu.cpp
│   │
│   ├── 📡 Wireless Modules
│   │   ├── wifi_deauth.h / wifi_deauth.cpp
│   │   ├── nethercap_core.h / nethercap_core.cpp
│   │   ├── wifi_scanner.h / wifi_scanner.cpp
│   │   ├── ble_module.h / ble_module.cpp
│   │   ├── ble_analyzer.h / ble_analyzer.cpp
│   │   ├── subghz.h / subghz.cpp
│   │   ├── subghz_analyzer.h / subghz_analyzer.cpp
│   │
│   ├── 🆔 RFID/NFC Modules
│   │   ├── nfc_module.h / nfc_module.cpp
│   │   ├── nfc_analyzer.h / nfc_analyzer.cpp
│   │   ├── rfid_module.h / rfid_module.cpp
│   │   ├── rfid_125khz.h / rfid_125khz.cpp
│   │
│   ├── 🔑 Other Modules
│   │   ├── ibutton.h / ibutton.cpp
│   │   ├── ir_remote.h / ir_remote.cpp
│   │   ├── ir_decoder.h / ir_decoder.cpp
│   │   ├── badusb.h / badusb.cpp
│   │   ├── ch9326.h / ch9326.cpp
│   │   ├── gpio_control.h / gpio_control.cpp
│   │   ├── touch_driver.h / touch_driver.cpp
│   │   ├── ota_update.h / ota_update.cpp
│   │   ├── buzzer.h / buzzer.cpp
│   │
│   └── 📄 MRJ_FW_V2.ino     # Setup & Loop
│
├── 📁 data/                   # Web assets (SPIFFS)
│   ├── index.html            # Web dashboard
│   └── pinout.html           # Pinout reference
│
└── 📄 README.md              # This file
```

## 📚 Required Libraries

### Auto-Install (via `lib_deps` in `platformio.ini`)

| Library | Purpose |
|---------|---------|
| `olikraus/U8g2` | OLED display backup |
| `adafruit/Adafruit GFX Library` | Core graphics |
| `adafruit/Adafruit ST7735 and ST7789 Library` | **Main TFT display** |
| `adafruit/Adafruit ILI9341` | Alternative TFT |
| `adafruit/Adafruit ILI9488` | Alternative TFT |
| `bblanchon/ArduinoJson` | JSON API parsing |
| `me-no-dev/AsyncTCP` | Async TCP backend |
| `me-no-dev/ESP Async WebServer` | **Web server** |
| `DNSServer` | Captive portal (built-in) |

### Built-in ESP32 Core (no install needed)
- `WiFi.h`, `SPI.h`, `Wire.h`, `EEPROM.h`, `SD.h`, `Update.h`
- `BLEDevice.h`, `esp_wifi.h`, `HardwareSerial.h`

## 🔧 How to Build & Flash

### Prerequisites
- [VS Code](https://code.visualstudio.com/) + [PlatformIO Extension](https://platformio.org/install/ide?install=vscode)
- ESP32 DevKit V1 (30-pin)
- USB cable

### Steps

```bash
# 1. Extract the ZIP file
# 2. Open folder in VS Code
# 3. Click the Build icon (✓) — libraries auto-download
# 4. Connect ESP32 via USB
# 5. Click Upload (→)
```

### After Flashing
1. Connect to WiFi `MRJ_AP` (open, no password)
2. Open browser → `192.168.4.1`
3. Login: `admin` / `mrj12345`
4. Enable modules via **Module Control**
5. Use features as needed!

## 🎮 Default Module States

| Module | Default | Control |
|--------|---------|---------|
| IR Receiver | ✅ ON | Always active |
| IR Transmitter | ❌ OFF | EEPROM |
| NFC | ❌ OFF | EEPROM (Team B) |
| RFID | ❌ OFF | EEPROM (Team B) |
| RFID 125kHz | ❌ OFF | EEPROM (Team B) |
| CC1101 | ❌ OFF | EEPROM (Team A) |
| CH9326/BadUSB | ❌ OFF | EEPROM (Team A) |
| Touch | ❌ OFF | EEPROM |

---

<a name="indonesia-section"></a>
# 🇮🇩 Indonesia

## 📋 Gambaran Umum

MRJ Firmware V2 adalah firmware serba-guna untuk ESP32 DevKit V1 yang dirancang untuk pengujian keamanan nirkabel, analisis perangkat IoT, dan kontrol hardware. Dibangun dengan arsitektur modular dan sistem pin sharing berbasis tim untuk memaksimalkan efisiensi GPIO.

## ✨ Fitur

| Kategori | Fitur |
|----------|-------|
| **🖥️ Display** | TFT ST7735 1.77" 128x160 dengan splash screen, progress boot, sistem menu |
| **📡 WiFi** | Serangan deauth, Evil Twin, Captive Portal, Beacon Spam, Scanner jaringan |
| **📶 BLE** | Scanner perangkat, BLE Spam, Analisis advertisement |
| **📻 Sub-GHz** | Dukungan CC1101 (300-928 MHz), scan frekuensi, RX/TX |
| **🆔 RFID/NFC** | MFRC522 (13.56 MHz), PN532 NFC, EM4100 (125 kHz) baca/clone/emulasi |
| **🔑 iButton** | Baca & emulasi kunci Dallas/Maxim 1-Wire |
| **🔴 IR Remote** | Rekam, Mainkan, Decode (protokol NEC/Sony/RC5) |
| **⌨️ BadUSB** | Automasi keyboard HID CH9326 (gaya Ducky Script) |
| **🔧 GPIO Control** | Kontrol pin via web dengan proteksi pin terlarang |
| **💾 SD Card** | File manager, logging, penyimpanan capture, eksekusi script |
| **🌐 Web Dashboard** | Kontrol penuh via browser dengan API JSON |
| **📦 OTA Update** | Update firmware via WiFi |
| **⚙️ Module Control** | Aktif/nonaktif modul tanpa restart (EEPROM) |

## 🏗️ Arsitektur / Sistem Tim

```
┌─────────────────────────────────────────────────────────────┐
│                    SISTEM TIM MRJ V2                       │
├──────────────────────────────┬──────────────────────────────┤
│        🔴 TIM A              │        🔵 TIM B            │
│     (Serang/Transmit)        │      (Baca/Clone)          │
├──────────────────────────────┼──────────────────────────────┤
│  📻 CC1101 (Sub-GHz)        │  📡 NFC PN532 (I2C)        │
│  ⌨️ CH9326 (BadUSB)         │  🆔 RFID MFRC522 (SPI)     │
│                              │  🆔 RFID 125kHz (UART)     │
├──────────────────────────────┴──────────────────────────────┤
│  ⚔️ Eksklusi Tim: Tim A aktif → Tim B otomatis mati        │
│  ⚔️ Pin Bersama: GPIO 0, 3, 15, 39 (bergantian)           │
└─────────────────────────────────────────────────────────────┘
```

> **Kenapa Tim?** Tim A dan Tim B menggunakan pin yang sama tapi tidak pernah aktif bersamaan. Desain pin-sharing ini memungkinkan 4 modul opsional berjalan hanya dengan 4 pin GPIO tambahan!

## 📌 Diagram Pinout

![MRJ V2 Pinout](mrj%20v2.png)

<details>
<summary>📎 Klik untuk tabel pin detail</summary>

### Modul Inti (Selalu Aktif)

| Modul | Pin ESP32 | Tipe |
|-------|-----------|------|
| TFT ST7735 SCK | GPIO 18 | VSPI |
| TFT ST7735 MISO | GPIO 19 | VSPI |
| TFT ST7735 MOSI | GPIO 23 | VSPI |
| TFT ST7735 CS | GPIO 5 | VSPI |
| TFT ST7735 DC | GPIO 21 | VSPI |
| TFT ST7735 RST | GPIO 22 | VSPI |
| SD Card SCK | GPIO 14 | HSPI |
| SD Card MISO | GPIO 26 | HSPI |
| SD Card MOSI | GPIO 27 | HSPI |
| SD Card CS | GPIO 4 | HSPI |
| NFC SDA | GPIO 16 | I2C |
| NFC SCL | GPIO 17 | I2C |
| NFC IRQ | GPIO 35 | Input |
| IR Receiver | GPIO 36 | Input-Only |
| IR Transmitter | GPIO 12 | Output |
| iButton Data | GPIO 2 | 1-Wire |
| Buzzer PWM | GPIO 13 | PWM |
| Tombol UP | GPIO 32 | Input |
| Tombol DOWN | GPIO 33 | Input |
| Tombol SELECT | GPIO 25 | Input |
| Tombol BACK | GPIO 34 | Input-Only |
| Baterai ADC | GPIO 37 | ADC |

### Pin Bersama (Tim A ↔ Tim B)

| Pin | Tim A (Aktif) | Tim B (Aktif) |
|-----|---------------|---------------|
| GPIO 0 | CC1101 CS | RFID CS |
| GPIO 3 | CC1101 GDO0 | RFID RST |
| GPIO 15 | CH9326 TX | RFID125 TX |
| GPIO 39 | CH9326 RX | RFID125 RX |

</details>

## 📁 Struktur Kode

```
mrj_fw_v2/
├── 📄 platformio.ini          # Konfigurasi build
├── 📁 src/                    # Kode sumber
│   ├── 📄 MRJ_FW_V2.ino      # Titik masuk utama
│   ├── 📄 config.h           # Konstanta firmware & layout EEPROM
│   ├── 📄 hardware_pinout.h  # Definisi pin GPIO
│   │
│   ├── 🖥️ Sistem Display
│   │   ├── display.h / display.cpp
│   │
│   ├── 🧠 Manajer Inti
│   │   ├── eeprom_manager.h / eeprom_manager.cpp
│   │   ├── reserved_pins.h / reserved_pins.cpp
│   │   ├── logger.h / logger.cpp
│   │   ├── sd_card.h / sd_card.cpp
│   │   ├── menu.h / menu.cpp
│   │
│   ├── 📡 Modul Nirkabel
│   │   ├── wifi_deauth.h / wifi_deauth.cpp
│   │   ├── nethercap_core.h / nethercap_core.cpp
│   │   ├── wifi_scanner.h / wifi_scanner.cpp
│   │   ├── ble_module.h / ble_module.cpp
│   │   ├── ble_analyzer.h / ble_analyzer.cpp
│   │   ├── subghz.h / subghz.cpp
│   │   ├── subghz_analyzer.h / subghz_analyzer.cpp
│   │
│   ├── 🆔 Modul RFID/NFC
│   │   ├── nfc_module.h / nfc_module.cpp
│   │   ├── nfc_analyzer.h / nfc_analyzer.cpp
│   │   ├── rfid_module.h / rfid_module.cpp
│   │   ├── rfid_125khz.h / rfid_125khz.cpp
│   │
│   ├── 🔑 Modul Lainnya
│   │   ├── ibutton.h / ibutton.cpp
│   │   ├── ir_remote.h / ir_remote.cpp
│   │   ├── ir_decoder.h / ir_decoder.cpp
│   │   ├── badusb.h / badusb.cpp
│   │   ├── ch9326.h / ch9326.cpp
│   │   ├── gpio_control.h / gpio_control.cpp
│   │   ├── touch_driver.h / touch_driver.cpp
│   │   ├── ota_update.h / ota_update.cpp
│   │   ├── buzzer.h / buzzer.cpp
│   │
│   └── 📄 MRJ_FW_V2.ino     # Setup & Loop
│
├── 📁 data/                   # Aset web (SPIFFS)
│   ├── index.html            # Dashboard web
│   └── pinout.html           # Referensi pinout
│
└── 📄 README.md              # File ini
```

## 📚 Library yang Diperlukan

### Auto-Install (via `lib_deps` di `platformio.ini`)

| Library | Tujuan |
|---------|--------|
| `olikraus/U8g2` | Cadangan display OLED |
| `adafruit/Adafruit GFX Library` | Grafik dasar |
| `adafruit/Adafruit ST7735 and ST7789 Library` | **Display TFT utama** |
| `adafruit/Adafruit ILI9341` | TFT alternatif |
| `adafruit/Adafruit ILI9488` | TFT alternatif |
| `bblanchon/ArduinoJson` | Parsing API JSON |
| `me-no-dev/AsyncTCP` | Backend TCP async |
| `me-no-dev/ESP Async WebServer` | **Web server** |
| `DNSServer` | Portal captive (built-in) |

### Built-in ESP32 Core (tidak perlu install)
- `WiFi.h`, `SPI.h`, `Wire.h`, `EEPROM.h`, `SD.h`, `Update.h`
- `BLEDevice.h`, `esp_wifi.h`, `HardwareSerial.h`

## 🔧 Cara Build & Flash

### Persyaratan
- [VS Code](https://code.visualstudio.com/) + [Ekstensi PlatformIO](https://platformio.org/install/ide?install=vscode)
- ESP32 DevKit V1 (30-pin)
- Kabel USB

### Langkah

```bash
# 1. Extract file ZIP
# 2. Buka folder di VS Code
# 3. Klik ikon Build (✓) — library otomatis ter-download
# 4. Sambung ESP32 via USB
# 5. Klik Upload (→)
```

### Setelah Flashing
1. Connect ke WiFi `MRJ_AP` (open, tanpa password)
2. Buka browser → `192.168.4.1`
3. Login: `admin` / `mrj12345`
4. Aktifkan modul via **Module Control**
5. Gunakan fitur sesuai kebutuhan!

## 🎮 Status Modul Default

| Modul | Default | Kontrol |
|-------|---------|---------|
| IR Receiver | ✅ ON | Selalu aktif |
| IR Transmitter | ❌ OFF | EEPROM |
| NFC | ❌ OFF | EEPROM (Tim B) |
| RFID | ❌ OFF | EEPROM (Tim B) |
| RFID 125kHz | ❌ OFF | EEPROM (Tim B) |
| CC1101 | ❌ OFF | EEPROM (Tim A) |
| CH9326/BadUSB | ❌ OFF | EEPROM (Tim A) |
| Touch | ❌ OFF | EEPROM |

---

## ⚠️ Disclaimer

> **EN:** This firmware is intended for educational and authorized security testing purposes only. The authors are not responsible for any misuse or illegal activities.

> **ID:** Firmware ini ditujukan untuk tujuan edukasi dan pengujian keamanan yang sah saja. Penulis tidak bertanggung jawab atas penyalahgunaan atau aktivitas ilegal.

---

<div align="center">

**Made with 🔥 by MRJ Team**

[![GitHub](https://img.shields.io/badge/GitHub-Repo-181717?style=flat&logo=github)](https://github.com/yourusername/mrj-fw-v2)
[![PlatformIO](https://img.shields.io/badge/PlatformIO-ESP32-orange?style=flat&logo=platformio)](https://platformio.org/)

</div>
