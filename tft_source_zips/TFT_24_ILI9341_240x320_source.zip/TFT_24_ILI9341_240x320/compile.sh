#!/bin/bash
FQBN="esp32:esp32:esp32"
DIR="$(cd "$(dirname "$0")" && pwd)"
FLAGS="-DMRJ_DISPLAY_ILI9341_24 -DMRJ_DISPLAY_WIDTH=240 -DMRJ_DISPLAY_HEIGHT=320"
arduino-cli compile --fqbn "$FQBN" --build-property "compiler.cpp.extra_flags=$FLAGS" --build-property "compiler.c.extra_flags=$FLAGS" "$DIR"
