# TFT_35_ILI9488_TFT_eSPI

3.5" ILI9488 320x480 using **TFT_eSPI** (Bodmer)

## Setup TFT_eSPI
Either edit libraries/TFT_eSPI/User_Setup.h OR use the flags in compile.sh.

## Compile
```bash
./compile.sh
```

## Libraries
- TFT_eSPI
- ArduinoJson
- ESPAsyncWebServer + AsyncTCP
