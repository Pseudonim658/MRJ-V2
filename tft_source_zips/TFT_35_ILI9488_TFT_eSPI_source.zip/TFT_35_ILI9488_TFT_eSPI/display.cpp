#include "display.h"
#include "logger.h"

DisplayModule display;

DisplayModule::DisplayModule() {}

DisplayModule::~DisplayModule() {}

bool DisplayModule::begin() {
    // Pins sudah di-set via build_flags TFT_eSPI
    tft.init();
    tft.setRotation(0);
    tft.fillScreen(THEME_BG);
    tft.setTextColor(THEME_TEXT, THEME_BG);
    tft.setTextSize(1);
    tft.setTextDatum(TL_DATUM);

    width = tft.width();
    height = tft.height();
    initialized = true;

    char msg[48];
    snprintf(msg, sizeof(msg), "TFT_eSPI ILI9488 ready (%dx%d)", width, height);
    logger.log(LOG_INFO, "DISPLAY", msg);
    return true;
}

void DisplayModule::clear() {
    if (!initialized) return;
    tft.fillScreen(THEME_BG);
}

void DisplayModule::update() {
    // TFT_eSPI draws immediately — no buffer flush needed
}

void DisplayModule::drawString(int x, int y, const char* text, uint16_t color) {
    if (!initialized || !text) return;
    tft.setTextColor(color, THEME_BG);
    tft.setTextDatum(TL_DATUM);
    tft.drawString(text, x, y);
}

void DisplayModule::drawStringCenter(int y, const char* text, uint16_t color) {
    if (!initialized || !text) return;
    tft.setTextColor(color, THEME_BG);
    tft.setTextDatum(TC_DATUM);
    tft.drawString(text, width / 2, y);
}

void DisplayModule::drawPixel(int x, int y, uint16_t color) {
    if (!initialized) return;
    tft.drawPixel(x, y, color);
}

void DisplayModule::drawLine(int x1, int y1, int x2, int y2, uint16_t color) {
    if (!initialized) return;
    tft.drawLine(x1, y1, x2, y2, color);
}

void DisplayModule::drawRect(int x, int y, int w, int h, uint16_t color) {
    if (!initialized) return;
    tft.drawRect(x, y, w, h, color);
}

void DisplayModule::fillRect(int x, int y, int w, int h, uint16_t color) {
    if (!initialized) return;
    tft.fillRect(x, y, w, h, color);
}

void DisplayModule::drawBitmap(int x, int y, const uint8_t* bitmap, int w, int h, uint16_t color) {
    if (!initialized || !bitmap) return;
    tft.drawBitmap(x, y, bitmap, w, h, color);
}

void DisplayModule::showSplash() {
    clear();
    drawStringCenter(height / 3, "mrj v" FIRMWARE_VERSION, THEME_TEXT);
    delay(2000);
}

void DisplayModule::showStatus(const char* line1, const char* line2, const char* line3) {
    clear();
    drawString(4, 10, line1);
    if (line2 && strlen(line2) > 0) drawString(4, 30, line2);
    if (line3 && strlen(line3) > 0) drawString(4, 50, line3);
}

void DisplayModule::showIP(const char* ip) {
    if (!ip) return;
    drawString(4, height - 16, ip);
}

void DisplayModule::showBootProgress(int percent, const char* module) {
    clear();
    drawStringCenter(height / 4, FIRMWARE_NAME);
    drawStringCenter(height / 4 + 20, "v" FIRMWARE_VERSION);

    int barWidth = width - 40;
    int barHeight = 12;
    int barX = 20;
    int barY = height / 2 + 10;
    drawRect(barX, barY, barWidth, barHeight, THEME_TEXT);
    int fill = (barWidth - 4) * constrain(percent, 0, 100) / 100;
    fillRect(barX + 2, barY + 2, fill, barHeight - 4, THEME_TEXT);

    char percentStr[8];
    snprintf(percentStr, sizeof(percentStr), "%d%%", percent);
    drawStringCenter(barY + barHeight + 16, percentStr);
    if (module) drawStringCenter(barY + barHeight + 34, module);
}
